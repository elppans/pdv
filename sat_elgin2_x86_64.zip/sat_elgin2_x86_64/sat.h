#ifndef SATELGIN_H
#define SATELGIN_H

#ifndef APIENTRY
#ifdef _WIN32
#define APIENTRY    __stdcall
#else
#define APIENTRY
#endif
#endif

struct stCOMM_ERROR
{
   unsigned long code;
   char          msg[300];
};

typedef struct stCOMM_ERROR COMM_ERROR;

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

int APIENTRY AbreSerialSAT(int commPort,
                           int nBaudRate,
                           int nBits,
                           int nParity,
                           int nStopBits);

char *APIENTRY AssociarAssinatura(int        numSessao,
                                  const char *codAtivacao,
                                  const char *conjuntoCNPJ,
                                  const char *signAC);

char *APIENTRY AtivarSAT(int        numSessao,
                         int        tipoCertificado,
                         const char *codAtivacao,
                         const char *cnpj,
                         int        cUF);

char *APIENTRY AtualizarSoftwareSAT(int        numSessao,
                                    const char *codAtivacao);

char *APIENTRY BloquearSAT(int        numSessao,
                           const char *codAtivacao);

char *APIENTRY CancelarUltimaVenda(int        numSessao,
                                   const char *codAtivacao,
                                   const char *chave,
                                   const char *dadosCanc);

COMM_ERROR APIENTRY CodigoErro(void);

char *APIENTRY ComunicarCertificadoICPBRASIL(int        numSessao,
                                             const char *codAtivacao,
                                             const char *certificado);

char *APIENTRY ConfigurarInterfaceDeRede(int        numSessao,
                                         const char *codAtivacao,
                                         const char *configRede);

char *APIENTRY ConsultarNumeroSessao(int        numSessao,
                                     const char *codAtivacao,
                                     int        numSessaoConsulta);

/**
 * Consulta o estado de conexão do SAT
 */
char *APIENTRY ConsultarSAT(int numSessao);

char *APIENTRY ConsultarStatusOperacional(int        numSessao,
                                          const char *codAtivacao);

char *APIENTRY ConsultarUltimaSessaoFiscal(int        numSessao,
                                           const char *codAtivacao);

char *APIENTRY DesbloquearSAT(int        numSessao,
                              const char *codAtivacao);

char *APIENTRY EnviarDadosVenda(int        numSessao,
                                const char *codAtivacao,
                                const char *dadosVenda);

/**
 * Consulta as informações de log disponível no equipamento
 */
char *APIENTRY ExtrairLogs(int        numSessao,
                           const char *codAtivacao);

/**
 * Gera número de sessão
 *
 * O número de sessão é garantido não foi utilizado pelo menos nas
 * últimas 100 comunicações.
 */
int APIENTRY GeraNumeroSessao(void);

char *APIENTRY TesteFimAFim(int        numSessao,
                            const char *codAtivacao,
                            const char *dadosVenda);

char *APIENTRY TrocarCodigoDeAtivacao(int        numSessao,
                                      const char *codAtivacaoAtual,
                                      int        opcao,
                                      const char *novoCodigo,
                                      const char *novoCodigoConfirma);

/**
 * Retorna um vetor de caracteres, com a informação de versão. É de
 * responsabilidade da função que chamar `VersaoLib` de desalocar a
 * memoria.
 */
char *APIENTRY VersaoLib(void);

char *APIENTRY sat_log_variaveis(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif /* SATELGIN_H */
