 
#!/bin/bash

#for i in `seq 30 -1 1` ; do
#        echo -ne "Aguarde $i Segundos.\r" ; sleep 1 ;
#done

chmod +x /Zanthus/Zeus/pdvJava/sleep-gui
/Zanthus/Zeus/pdvJava/sleep-gui

xinput map-to-output 11 DP-1 &
xinput map-to-output 12 HDMI-2 &

xrandr --output DP-1 --auto
#xrandr --output HDMI-2 --auto
xset -dpms
xset s noblank
xset s off
